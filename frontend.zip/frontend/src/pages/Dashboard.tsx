export default function Dashboard() {
  return <h2>Bienvenido al panel principal</h2>;
}
