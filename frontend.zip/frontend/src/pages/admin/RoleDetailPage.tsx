import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PermissionsAPI, RolesAPI, type Permission, type Role } from '@/api/roles';
import { UsersAPI } from '@/api/users';

function Button(props: any) { return <button {...props} className={'px-3 py-2 border rounded-md ' + (props.className ?? '')} /> }
function Input(props: any) { return <input {...props} className={'px-3 py-2 border rounded-md w-full ' + (props.className ?? '')} /> }
function Checkbox({ checked, onChange }: {checked:boolean, onChange:()=>void}) {
  return <input type="checkbox" checked={checked} onChange={onChange} />;
}

export default function RoleDetailPage() {
  const { id } = useParams();
  const roleId = Number(id);
  const qc = useQueryClient();

  const { data: detail } = useQuery({
    queryKey: ['role', roleId],
    queryFn: () => RolesAPI.detail(roleId).then(r => r.data),
  });
  const { data: allPerms } = useQuery({
    queryKey: ['permissions'],
    queryFn: () => PermissionsAPI.list().then(r => r.data),
  });

  const [meta, setMeta] = useState<Partial<Role>>({});
  const [selectedPerms, setSelectedPerms] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const { data: usersFound } = useQuery({
    queryKey: ['users-basic', search],
    queryFn: () => UsersAPI.listBasic(search).then(r => r.data),
  });
  const [selectedUsers, setSelectedUsers] = useState<Set<number>>(new Set());

  useEffect(() => {
    if (detail?.role) {
      setMeta(detail.role);
      setSelectedPerms(new Set((detail.permissions ?? []).map(p => p.key)));
      setSelectedUsers(new Set((detail.users ?? []).map(u => u.id)));
    }
  }, [detail]);

  const permsByCat = useMemo(() => {
    const g: Record<string, Permission[]> = {};
    (allPerms ?? []).forEach((p) => {
      const cat = (p as any).categoria || 'General';
      g[cat] = g[cat] || [];
      g[cat].push(p);
    });
    return g;
  }, [allPerms]);

  const togglePerm = (key: string) => {
    const next = new Set(selectedPerms);
    next.has(key) ? next.delete(key) : next.add(key);
    setSelectedPerms(next);
  };
  const toggleUser = (uid: number) => {
    const next = new Set(selectedUsers);
    next.has(uid) ? next.delete(uid) : next.add(uid);
    setSelectedUsers(next);
  };

  const saveMeta = useMutation({
    mutationFn: () => RolesAPI.update(roleId, {
      nombre: meta.nombre,
      descripcion: meta.descripcion,
      soloEmpresaMaestra: meta.soloEmpresaMaestra,
    }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['role', roleId] }),
  });
  const savePerms = useMutation({
    mutationFn: () => RolesAPI.setPermissions(roleId, Array.from(selectedPerms)),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['role', roleId] }),
  });
  const saveUsers = useMutation({
    mutationFn: () => RolesAPI.setUsers(roleId, Array.from(selectedUsers)),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['role', roleId] }),
  });

  return (
    <div className="p-6 space-y-8">
      <div className="space-y-3 max-w-xl">
        <h1 className="text-2xl font-semibold">Rol #{roleId}</h1>
        <Input value={meta.nombre ?? ''} onChange={e => setMeta(s => ({ ...s, nombre: e.target.value }))} placeholder="Nombre" />
        <Input value={meta.descripcion ?? ''} onChange={e => setMeta(s => ({ ...s, descripcion: e.target.value }))} placeholder="Descripción" />
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={Boolean(meta.soloEmpresaMaestra)}
            onChange={(e)=> setMeta(s => ({ ...s, soloEmpresaMaestra: e.target.checked }))}
          />
          <span>Solo empresa maestra</span>
        </label>
        <Button onClick={()=>saveMeta.mutate()}>Guardar cambios</Button>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-medium">Permisos</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(permsByCat).map(([cat, list]) => (
            <div key={cat} className="border rounded-xl p-4">
              <div className="font-medium mb-2">{cat}</div>
              <div className="grid gap-2">
                {list.map(p => (
                  <label key={p.key} className="flex items-center gap-2">
                    <Checkbox checked={selectedPerms.has(p.key)} onChange={() => togglePerm(p.key)} />
                    <span className="text-sm">{p.nombre} <span className="opacity-60">({p.key})</span></span>
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
        <Button onClick={()=>savePerms.mutate()}>Guardar permisos</Button>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-medium">Usuarios del rol</h2>
        <Input placeholder="Buscar usuarios por nombre o email" value={search} onChange={e=>setSearch(e.target.value)} />
        <div className="max-h-64 overflow-auto border rounded-md">
          {(usersFound ?? []).map(u => (
            <label key={u.id} className="flex items-center gap-2 p-2 border-b">
              <input type="checkbox" checked={selectedUsers.has(u.id)} onChange={()=>toggleUser(u.id)} />
              <span className="text-sm">{u.nombre} <span className="opacity-60">&lt;{u.email}&gt;</span></span>
            </label>
          ))}
        </div>
        <Button onClick={()=>saveUsers.mutate()}>Guardar usuarios</Button>
      </div>
    </div>
  );
}
