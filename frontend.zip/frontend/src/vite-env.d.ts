
/// <reference types="vite/client" />

/**
 * This project uses Leaflet directly (not react-leaflet)
 * The proper Leaflet typings are provided by @types/leaflet which is already installed
 */
