#!/bin/bash
echo "Contenedor beloop-backend listo. Esperando comandos..."

# Esto mantiene el contenedor vivo sin hacer nada
#tail -f /dev/null
pnpm start:prod
