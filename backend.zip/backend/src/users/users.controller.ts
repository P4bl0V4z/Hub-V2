import { Controller, Get, Query, SetMetadata, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtCookieAuthGuard } from '../auth/guards/jwt-cookie.guard';
import { AuthzGuard } from '../authz/authz.guard';
import { AUTHZ_MIN, AUTHZ_OBJECT } from '../authz/authz.decorator';

@UseGuards(JwtCookieAuthGuard, AuthzGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly service: UsersService) {}

  @SetMetadata(AUTHZ_OBJECT, 'users')
  @SetMetadata(AUTHZ_MIN, 'VER')
  @Get()
  listBasic(@Query('q') q?: string) {
    return this.service.findBasic(q);
  }
}
